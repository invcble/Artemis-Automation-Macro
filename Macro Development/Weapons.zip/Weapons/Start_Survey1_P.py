import subprocess
import time

time.sleep(1)
subprocess.Popen(['start', 'https://drexel.qualtrics.com/jfe/form/SV_2gbBTwyemTFj46W'], shell = True)
time.sleep(1)