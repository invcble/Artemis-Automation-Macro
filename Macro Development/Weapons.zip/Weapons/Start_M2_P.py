import pyautogui as pag
import time

time.sleep(1)
pag.moveTo(383,28) #Closechrome
pag.mouseUp()
pag.mouseDown()
pag.mouseUp()
time.sleep(1)