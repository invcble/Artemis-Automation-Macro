import subprocess
import time

time.sleep(1)
subprocess.Popen(['start', 'https://drexel.qualtrics.com/jfe/form/SV_bClOWafnNkwIPrw'], shell = True)
time.sleep(1)