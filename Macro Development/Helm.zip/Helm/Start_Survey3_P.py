import subprocess
import time

time.sleep(1)
subprocess.Popen(['start', 'https://drexel.qualtrics.com/jfe/form/SV_3UAxJrtri8j9au2'], shell = True)
time.sleep(1)