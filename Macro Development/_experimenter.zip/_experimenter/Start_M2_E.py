import pyautogui as pag
import time


time.sleep(1)
pag.moveTo(1798,1079) #Endgame
pag.mouseDown()
pag.mouseUp()
time.sleep(2)
pag.moveTo(1537,394) #Layoutswitch
pag.mouseDown()
pag.mouseUp()
time.sleep(1)
#WAIT FOR MANUAL START