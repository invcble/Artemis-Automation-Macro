import os
import time


time.sleep(1)
os.system("taskkill /im Artemis.exe /f")
time.sleep(2)